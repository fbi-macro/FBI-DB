--------------------------------------------------------
--  ������ ������ - �����-6��-22-2019   
--------------------------------------------------------
DROP SEQUENCE "FBI"."COMM_SEQ";
DROP SEQUENCE "FBI"."DESSERT_SEQ";
DROP SEQUENCE "FBI"."ENTERTAIMENT_SEQ";
DROP SEQUENCE "FBI"."LODGMENT_SEQ";
DROP SEQUENCE "FBI"."RESTAURANT_SEQ";
DROP SEQUENCE "FBI"."STORE_SEQ";
DROP SEQUENCE "FBI"."USER_VOTE_SEQ";
DROP SEQUENCE "FBI"."VOTE_SEQ";
DROP TABLE "FBI"."BUILDING" cascade constraints;
DROP TABLE "FBI"."COMMENTS" cascade constraints;
DROP TABLE "FBI"."DESSERT" cascade constraints;
DROP TABLE "FBI"."ENTERTAIMENT" cascade constraints;
DROP TABLE "FBI"."LODGMENT" cascade constraints;
DROP TABLE "FBI"."RESTAURANT" cascade constraints;
DROP TABLE "FBI"."STORE" cascade constraints;
DROP TABLE "FBI"."USERINFO" cascade constraints;
DROP TABLE "FBI"."USER_VOTE" cascade constraints;
DROP TABLE "FBI"."VOTING" cascade constraints;
--------------------------------------------------------
--  DDL for Sequence COMM_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FBI"."COMM_SEQ"  MINVALUE 1 MAXVALUE 1000 INCREMENT BY 1 START WITH 4 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence DESSERT_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FBI"."DESSERT_SEQ"  MINVALUE 1 MAXVALUE 10000 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence ENTERTAIMENT_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FBI"."ENTERTAIMENT_SEQ"  MINVALUE 1 MAXVALUE 10000 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LODGMENT_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FBI"."LODGMENT_SEQ"  MINVALUE 1 MAXVALUE 10000 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence RESTAURANT_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FBI"."RESTAURANT_SEQ"  MINVALUE 1 MAXVALUE 10000 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence STORE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FBI"."STORE_SEQ"  MINVALUE 1 MAXVALUE 10000 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence USER_VOTE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FBI"."USER_VOTE_SEQ"  MINVALUE 1 MAXVALUE 1000 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence VOTE_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "FBI"."VOTE_SEQ"  MINVALUE 1 MAXVALUE 1000 INCREMENT BY 1 START WITH 3 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Table BUILDING
--------------------------------------------------------

  CREATE TABLE "FBI"."BUILDING" 
   (	"BDID" NUMBER(10,0), 
	"LOCATION_X" NUMBER(3,14) DEFAULT 0, 
	"LOCATION_Y" NUMBER(3,14) DEFAULT 0, 
	"ADDRESS" VARCHAR2(100 BYTE), 
	"MONTH_PAY" NUMBER(10,0) DEFAULT 0, 
	"ALL_PAY" NUMBER(10,0) DEFAULT 0, 
	"MANAGE_PAY" NUMBER(10,0) DEFAULT 0, 
	"USERID" VARCHAR2(20 BYTE), 
	"CATEGORY" VARCHAR2(20 BYTE), 
	"FUNDINGYN" CHAR(1 BYTE), 
	"STARTDATE" DATE, 
	"ENDDATE" DATE
   ) SEGMENT CREATION DEFERRED 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table COMMENTS
--------------------------------------------------------

  CREATE TABLE "FBI"."COMMENTS" 
   (	"COMM_IDX" NUMBER(7,0), 
	"COMM" VARCHAR2(200 BYTE), 
	"USERID" VARCHAR2(20 BYTE), 
	"UPNUM" NUMBER(10,0) DEFAULT 0
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table DESSERT
--------------------------------------------------------

  CREATE TABLE "FBI"."DESSERT" 
   (	"DESSERT_IDX" NUMBER(10,0), 
	"BUILDNUM" NUMBER(10,0), 
	"COFFEE" NUMBER(3,0) DEFAULT 0, 
	"BAKERY" NUMBER(3,0) DEFAULT 0, 
	"ICECREAM" NUMBER(3,0) DEFAULT 0, 
	"DOUGHNUT" NUMBER(3,0) DEFAULT 0
   ) SEGMENT CREATION DEFERRED 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table ENTERTAIMENT
--------------------------------------------------------

  CREATE TABLE "FBI"."ENTERTAIMENT" 
   (	"ENTERTAIMENT_IDX" NUMBER(10,0), 
	"BUILDNUM" NUMBER(10,0), 
	"FITNESS" NUMBER(3,0) DEFAULT 0, 
	"SCREENGOLF" NUMBER(3,0) DEFAULT 0, 
	"BILLIARD" NUMBER(3,0) DEFAULT 0, 
	"PC" NUMBER(3,0) DEFAULT 0, 
	"YOGA" NUMBER(3,0) DEFAULT 0, 
	"MASSAGE" NUMBER(3,0) DEFAULT 0, 
	"NAILCARE" NUMBER(3,0) DEFAULT 0, 
	"KARAOKE" NUMBER(3,0) DEFAULT 0
   ) SEGMENT CREATION DEFERRED 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table LODGMENT
--------------------------------------------------------

  CREATE TABLE "FBI"."LODGMENT" 
   (	"LODGMENT_IDX" NUMBER(10,0), 
	"BUILDNUM" NUMBER(10,0), 
	"HOTEL" NUMBER(3,0) DEFAULT 0, 
	"MOTEL" NUMBER(3,0) DEFAULT 0
   ) SEGMENT CREATION DEFERRED 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table RESTAURANT
--------------------------------------------------------

  CREATE TABLE "FBI"."RESTAURANT" 
   (	"RESTAURANT_IDX" NUMBER(10,0), 
	"BUILDNUM" NUMBER(10,0), 
	"KRFOOD" NUMBER(3,0) DEFAULT 0, 
	"CHIFOOD" NUMBER(3,0) DEFAULT 0, 
	"JAPFOOD" NUMBER(3,0) DEFAULT 0, 
	"VIETFOOD" NUMBER(3,0) DEFAULT 0, 
	"SNACKBAR" NUMBER(3,0) DEFAULT 0, 
	"RESTAURANT" NUMBER(3,0) DEFAULT 0, 
	"BAR" NUMBER(3,0) DEFAULT 0, 
	"CHICKEN" NUMBER(3,0) DEFAULT 0, 
	"BEER" NUMBER(3,0) DEFAULT 0, 
	"PIZZA" NUMBER(3,0) DEFAULT 0, 
	"HAMBURGER" NUMBER(3,0) DEFAULT 0, 
	"MEATREST" NUMBER(3,0) DEFAULT 0
   ) SEGMENT CREATION DEFERRED 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table STORE
--------------------------------------------------------

  CREATE TABLE "FBI"."STORE" 
   (	"STORE_IDX" NUMBER(10,0), 
	"BUILDNUM" NUMBER(10,0), 
	"ACCESSORY" NUMBER(3,0) DEFAULT 0, 
	"CONVENIENSTORE" NUMBER(3,0) DEFAULT 0, 
	"COSMETICS" NUMBER(3,0) DEFAULT 0, 
	"PHONE" NUMBER(3,0) DEFAULT 0
   ) SEGMENT CREATION DEFERRED 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table USERINFO
--------------------------------------------------------

  CREATE TABLE "FBI"."USERINFO" 
   (	"USERID" VARCHAR2(20 BYTE), 
	"USERPASS" VARCHAR2(20 BYTE), 
	"FOUNDERYN" CHAR(1 BYTE), 
	"MYBUILDING" NUMBER(20,0), 
	"ACCOUNT" VARCHAR2(20 BYTE), 
	"BANK" VARCHAR2(10 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table USER_VOTE
--------------------------------------------------------

  CREATE TABLE "FBI"."USER_VOTE" 
   (	"USER_VOTE_IDX" NUMBER(3,0), 
	"USERID" VARCHAR2(20 BYTE), 
	"VOTE_BUILD_ID" NUMBER(20,0)
   ) SEGMENT CREATION DEFERRED 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  DDL for Table VOTING
--------------------------------------------------------

  CREATE TABLE "FBI"."VOTING" 
   (	"VOTE_IDX" NUMBER(7,0), 
	"BDID" NUMBER(10,0), 
	"DESSERT" NUMBER(3,0) DEFAULT 0, 
	"RESTAURANT" NUMBER(3,0) DEFAULT 0, 
	"STORE" NUMBER(3,0) DEFAULT 0, 
	"ENTER" NUMBER(3,0) DEFAULT 0, 
	"LODGMENT" NUMBER(3,0) DEFAULT 0
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
REM INSERTING into FBI.BUILDING
SET DEFINE OFF;
REM INSERTING into FBI.COMMENTS
SET DEFINE OFF;
REM INSERTING into FBI.DESSERT
SET DEFINE OFF;
REM INSERTING into FBI.ENTERTAIMENT
SET DEFINE OFF;
REM INSERTING into FBI.LODGMENT
SET DEFINE OFF;
REM INSERTING into FBI.RESTAURANT
SET DEFINE OFF;
REM INSERTING into FBI.STORE
SET DEFINE OFF;
REM INSERTING into FBI.USERINFO
SET DEFINE OFF;
Insert into FBI.USERINFO (USERID,USERPASS,FOUNDERYN,MYBUILDING,ACCOUNT,BANK) values ('admin','1234','N',null,'1234','KB');
REM INSERTING into FBI.USER_VOTE
SET DEFINE OFF;
REM INSERTING into FBI.VOTING
SET DEFINE OFF;
--------------------------------------------------------
--  DDL for Trigger DESSERT_TRIGER
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "FBI"."DESSERT_TRIGER" 
after
update on dessert
for each row
begin
    update voting
    set dessert = :new.coffee+:new.bakery+:new.icecream+:new.doughnut
    where bdId = :old.buildnum;
end;
--#####################################################################################--
create table restaurant(
restaurant_idx number(10) primary key,
buildnum number(10),
krFood number(3) default 0,--�ѽ�
chiFood number(3) default 0,--�߽�
japFood number(3) default 0,--�Ͻ�
vietFood number(3) default 0,--��Ʈ������
snackBar number(3) default 0,--�н���
restaurant number(3) default 0,--�������
bar number(3) default 0,--��
chicken number(3) default 0,--ġŲ
beer number(3) default 0,--����
pizza number(3) default 0,--����
hamburger number(3) default 0,--�ܹ���
meatRest number(3) default 0,--������
constraint bd_restaurant_fk foreign key(buildnum) references building(bdId) on delete cascade
);
create sequence restaurant_seq Start with 1 increment by 1 maxvalue 10000 nocycle nocache;


--#####################################################################################--

create table store(
store_idx number(10) primary key,
buildnum number(10),
accessory number(3) default 0,--�Ǽ��縮
convenienStore number(3) default 0,--������
cosmetics number(3) default 0,--ȭ��ǰ
phone number(3) default 0,--�ڵ��� ������
constraint bd_store_fk foreign key(buildnum) references building(bdId) on delete cascade
);
create sequence store_seq Start with 1 increment by 1 maxvalue 10000 nocycle nocache;

create or replace trigger store_triger
after
update on store
for each row
begin
    update voting
    set store = :new.accessory+:new.convenienStore+:new.cosmetics+:new.phone
    where bdId = :old.buildnum;
end;


--#####################################################################################--
create table lodgment(
lodgment_idx number(10) primary key,
buildnum number(10),
hotel number(3) default 0, --ȣ��
motel number(3) default 0, --����
constraint bd_lodgment_fk foreign key(buildnum) references building(bdId) on delete cascade
);
create sequence lodgment_seq Start with 1 increment by 1 maxvalue 10000 nocycle nocache;
--#####################################################################################--
create table entertaiment(
entertaiment_idx number(10) primary key,
buildnum number(10),
fitness number(3) default 0,--�ｺ��
screenGolf number(3) default 0,--��ũ�� ����
billiard number(3) default 0,--�籸��
PC number(3) default 0,--�ǽù�
yoga number(3) default 0,-- �䰡
massage number(3) default 0,--������
nailCare number(3) default 0,--���ϼ�
karaoke number(3) default 0,--�뷡��
constraint bd_entertaiment_fk foreign key(buildnum) references building(bdId) on delete cascade
);
create sequence entertaiment_seq Start with 1 increment by 1 maxvalue 10000 nocycle nocache;
--#####################################################################################--


create sequence comm_seq Start with 1 increment by 1 maxvalue 10000 nocycle nocache; -- comment���� ��� �� ������
insert into comments values(comm_seq.nextval,'�׽�Ʈ','admin',100);--�����Ҷ� comm_seq.nextval�� ����ؾ���

create sequence vote_seq Start with 1 increment by 1 maxvalue 1000 nocycle nocache;--vote���� ��� �� ������
insert into voting values(vote_seq.nextval,111,0,0,0,0,0); -- �����Ҷ� vote_seq.nextval ����ؾ���

select * from userInfo;--��������
select * from comments;--�������
select * from building;--�ǹ�����
select * from voting;--��ǥ����
--��ǥ�� ���̺�--
select * from dessert;
select * from restaurant;
select * from store;
select * from enter;
select * from lodgment;

commit;











/
ALTER TRIGGER "FBI"."DESSERT_TRIGER" ENABLE;
--------------------------------------------------------
--  DDL for Trigger DESSERT_TRIGGER
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "FBI"."DESSERT_TRIGGER" 
after
update on dessert
for each row
begin
    update voting
    set dessert = :new.coffee+:new.bakery+:new.icecream+:new.doughnut
    where bdId = :old.buildnum;
end;
--#####################################################################################--
create table restaurant(
restaurant_idx number(10) primary key,
buildnum number(10),
krFood number(3) default 0,--�ѽ�
chiFood number(3) default 0,--�߽�
japFood number(3) default 0,--�Ͻ�
vietFood number(3) default 0,--��Ʈ������
snackBar number(3) default 0,--�н���
restaurant number(3) default 0,--�������
bar number(3) default 0,--��
chicken number(3) default 0,--ġŲ
beer number(3) default 0,--����
pizza number(3) default 0,--����
hamburger number(3) default 0,--�ܹ���
meatRest number(3) default 0,--������
constraint bd_restaurant_fk foreign key(buildnum) references building(bdId) on delete cascade
);

create sequence restaurant_seq Start with 1 increment by 1 maxvalue 10000 nocycle nocache;


--#####################################################################################--

create table store(
store_idx number(10) primary key,
buildnum number(10),
accessory number(3) default 0,--�Ǽ��縮
convenienStore number(3) default 0,--������
cosmetics number(3) default 0,--ȭ��ǰ
phone number(3) default 0,--�ڵ��� ������
constraint bd_store_fk foreign key(buildnum) references building(bdId) on delete cascade
);
create sequence store_seq Start with 1 increment by 1 maxvalue 10000 nocycle nocache;
commit;
create or replace trigger store_trigger
after
update on store
for each row
begin
    update voting
    set store = :new.accessory+:new.convenienStore+:new.cosmetics+:new.phone
    where bdId = :old.buildnum;
end;

--#####################################################################################--
create table lodgment(
lodgment_idx number(10) primary key,
buildnum number(10),
hotel number(3) default 0, --ȣ��
motel number(3) default 0, --����
constraint bd_lodgment_fk foreign key(buildnum) references building(bdId) on delete cascade
);
create sequence lodgment_seq Start with 1 increment by 1 maxvalue 10000 nocycle nocache;

create or replace trigger lodgment_trigger
after
update on lodgment
for each row
begin
    update voting
    set store = :new.hotel+:new.motel
    where bdId = :old.buildnum;
end;

--#####################################################################################--
create table entertaiment(
entertaiment_idx number(10) primary key,
buildnum number(10),
fitness number(3) default 0,--�ｺ��
screenGolf number(3) default 0,--��ũ�� ����
billiard number(3) default 0,--�籸��
PC number(3) default 0,--�ǽù�
yoga number(3) default 0,-- �䰡
massage number(3) default 0,--������
nailCare number(3) default 0,--���ϼ�
karaoke number(3) default 0,--�뷡��
constraint bd_entertaiment_fk foreign key(buildnum) references building(bdId) on delete cascade
);
create sequence entertaiment_seq Start with 1 increment by 1 maxvalue 10000 nocycle nocache;

create or replace trigger entertaiment_trigger
after
update on entertaiment
for each row
begin
    update voting
    set store = 
    :new.fitness+:new.screenGolf+:new.billiard+:new.PC
    +:new.yoga+:new.massage+:new.nailCare
    +:new.karaoke
    where bdId = :old.buildnum;
end;
--#####################################################################################--


create sequence comm_seq Start with 1 increment by 1 maxvalue 10000 nocycle nocache; -- comment���� ��� �� ������
insert into comments values(comm_seq.nextval,'�׽�Ʈ','admin',100);--�����Ҷ� comm_seq.nextval�� ����ؾ���

create sequence vote_seq Start with 1 increment by 1 maxvalue 1000 nocycle nocache;--vote���� ��� �� ������
insert into voting values(vote_seq.nextval,111,0,0,0,0,0); -- �����Ҷ� vote_seq.nextval ����ؾ���

select * from userInfo;--��������
select * from comments;--�������
select * from building;--�ǹ�����
select * from voting;--��ǥ����
--��ǥ�� ���̺�--
select * from dessert;
select * from restaurant;
select * from store;
select * from enter;
select * from lodgment;

commit;











/
ALTER TRIGGER "FBI"."DESSERT_TRIGGER" ENABLE;
--------------------------------------------------------
--  DDL for Trigger ENTERTAIMENT_TRIGGER
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "FBI"."ENTERTAIMENT_TRIGGER" 
after
update on entertaiment
for each row
begin
    update voting
    set store = 
    :new.fitness+:new.screenGolf+:new.billiard+:new.PC
    +:new.yoga+:new.massage+:new.nailCare
    +:new.karaoke
    where bdId = :old.buildnum;
end;
/
ALTER TRIGGER "FBI"."ENTERTAIMENT_TRIGGER" ENABLE;
--------------------------------------------------------
--  DDL for Trigger LODGMENT_TRIGGER
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "FBI"."LODGMENT_TRIGGER" 
after
update on lodgment
for each row
begin
    update voting
    set store = :new.hotel+:new.motel
    where bdId = :old.buildnum;
end;
/
ALTER TRIGGER "FBI"."LODGMENT_TRIGGER" ENABLE;
--------------------------------------------------------
--  DDL for Trigger RESTAURANT_TRIGGER
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "FBI"."RESTAURANT_TRIGGER" 
after
update on restaurant
for each row
begin
    update voting
    set store = 
    :new.krFood+
:new.chiFood+:new.japFood+
:new.vietFood+:new.snackBar+:new.restaurant+
:new.bar+:new.chicken+:new.beer+
:new.pizza+:new.hamburger+:new.meatRest
    where bdId = :old.buildnum;
end;
/
ALTER TRIGGER "FBI"."RESTAURANT_TRIGGER" ENABLE;
--------------------------------------------------------
--  DDL for Trigger STORE_TRIGGER
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "FBI"."STORE_TRIGGER" 
after
update on store
for each row
begin
    update voting
    set store = :new.accessory+:new.convenienStore+:new.cosmetics+:new.phone
    where bdId = :old.buildnum;
end;
/
ALTER TRIGGER "FBI"."STORE_TRIGGER" ENABLE;
--------------------------------------------------------
--  Constraints for Table ENTERTAIMENT
--------------------------------------------------------

  ALTER TABLE "FBI"."ENTERTAIMENT" ADD PRIMARY KEY ("ENTERTAIMENT_IDX")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 NOCOMPRESS LOGGING
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table BUILDING
--------------------------------------------------------

  ALTER TABLE "FBI"."BUILDING" ADD CONSTRAINT "BULD_FOUND_CHECK" CHECK (fundingYN in ('Y','N')) ENABLE;
 
  ALTER TABLE "FBI"."BUILDING" MODIFY ("ADDRESS" NOT NULL ENABLE);
 
  ALTER TABLE "FBI"."BUILDING" ADD PRIMARY KEY ("BDID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOCOMPRESS LOGGING
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table LODGMENT
--------------------------------------------------------

  ALTER TABLE "FBI"."LODGMENT" ADD PRIMARY KEY ("LODGMENT_IDX")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 NOCOMPRESS LOGGING
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table STORE
--------------------------------------------------------

  ALTER TABLE "FBI"."STORE" ADD PRIMARY KEY ("STORE_IDX")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 NOCOMPRESS LOGGING
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table COMMENTS
--------------------------------------------------------

  ALTER TABLE "FBI"."COMMENTS" MODIFY ("COMM" NOT NULL ENABLE);
 
  ALTER TABLE "FBI"."COMMENTS" ADD PRIMARY KEY ("COMM_IDX")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table USERINFO
--------------------------------------------------------

  ALTER TABLE "FBI"."USERINFO" ADD CONSTRAINT "FOUND_CHECK" CHECK (founderYN in ('Y','N')) ENABLE;
 
  ALTER TABLE "FBI"."USERINFO" MODIFY ("USERPASS" NOT NULL ENABLE);
 
  ALTER TABLE "FBI"."USERINFO" ADD PRIMARY KEY ("USERID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table USER_VOTE
--------------------------------------------------------

  ALTER TABLE "FBI"."USER_VOTE" ADD PRIMARY KEY ("USER_VOTE_IDX")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS NOCOMPRESS LOGGING
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table DESSERT
--------------------------------------------------------

  ALTER TABLE "FBI"."DESSERT" ADD PRIMARY KEY ("DESSERT_IDX")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 NOCOMPRESS LOGGING
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table RESTAURANT
--------------------------------------------------------

  ALTER TABLE "FBI"."RESTAURANT" ADD PRIMARY KEY ("RESTAURANT_IDX")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 NOCOMPRESS LOGGING
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Constraints for Table VOTING
--------------------------------------------------------

  ALTER TABLE "FBI"."VOTING" ADD PRIMARY KEY ("VOTE_IDX")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table COMMENTS
--------------------------------------------------------

  ALTER TABLE "FBI"."COMMENTS" ADD CONSTRAINT "USERID_FK" FOREIGN KEY ("USERID")
	  REFERENCES "FBI"."USERINFO" ("USERID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table DESSERT
--------------------------------------------------------

  ALTER TABLE "FBI"."DESSERT" ADD CONSTRAINT "BD_DESSERT_FK" FOREIGN KEY ("BUILDNUM")
	  REFERENCES "FBI"."BUILDING" ("BDID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ENTERTAIMENT
--------------------------------------------------------

  ALTER TABLE "FBI"."ENTERTAIMENT" ADD CONSTRAINT "BD_ENTERTAIMENT_FK" FOREIGN KEY ("BUILDNUM")
	  REFERENCES "FBI"."BUILDING" ("BDID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table LODGMENT
--------------------------------------------------------

  ALTER TABLE "FBI"."LODGMENT" ADD CONSTRAINT "BD_LODGMENT_FK" FOREIGN KEY ("BUILDNUM")
	  REFERENCES "FBI"."BUILDING" ("BDID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table RESTAURANT
--------------------------------------------------------

  ALTER TABLE "FBI"."RESTAURANT" ADD CONSTRAINT "BD_RESTAURANT_FK" FOREIGN KEY ("BUILDNUM")
	  REFERENCES "FBI"."BUILDING" ("BDID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table STORE
--------------------------------------------------------

  ALTER TABLE "FBI"."STORE" ADD CONSTRAINT "BD_STORE_FK" FOREIGN KEY ("BUILDNUM")
	  REFERENCES "FBI"."BUILDING" ("BDID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table USERINFO
--------------------------------------------------------

  ALTER TABLE "FBI"."USERINFO" ADD CONSTRAINT "BUILDING_FK" FOREIGN KEY ("MYBUILDING")
	  REFERENCES "FBI"."BUILDING" ("BDID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table USER_VOTE
--------------------------------------------------------

  ALTER TABLE "FBI"."USER_VOTE" ADD CONSTRAINT "USER_VOTE_FK" FOREIGN KEY ("USERID")
	  REFERENCES "FBI"."USERINFO" ("USERID") ON DELETE CASCADE ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table VOTING
--------------------------------------------------------

  ALTER TABLE "FBI"."VOTING" ADD CONSTRAINT "VOTE_BUILDING_FK" FOREIGN KEY ("BDID")
	  REFERENCES "FBI"."BUILDING" ("BDID") ON DELETE CASCADE ENABLE;
